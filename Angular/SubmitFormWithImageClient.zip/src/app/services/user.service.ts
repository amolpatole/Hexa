import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { LoginUser } from '../models/loginUser';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  //readonly apiUrl = "http://localhost:59235/api/auth";
  readonly apiUrl = "https://amol-identityapi.azurewebsites.net/api/auth";
  userSubject: BehaviorSubject<any>;
  currentUser: Observable<any>;

  constructor(private http: HttpClient) {
    this.userSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem("user")));
    this.currentUser = this.userSubject.asObservable();
  }

  addUser(user: User): Observable<User> {
    // let options = {
    //   headers: {
    //     "Content-Type": "application/json",
    //     "Accept": "application/json"
    //   }
    // }
    // here we used interceptor
    return this.http.post<User>(`${this.apiUrl}/register`, user);
  }

  getToken(username: string, password: string): Observable<any> {
    let user = {
      username,
      password
    };
    return this.http.post<any>(`${this.apiUrl}/token`, user);
  }

  saveUserState(user) {
    // Remove password from userState object
    delete user.password;
    // Set user information to localstorage
    localStorage.setItem("user", JSON.stringify(user))
    this.userSubject.next(user);
  }

  removeUserState() {
    // To clear loacl storage
    localStorage.clear();
    // Again send the notification
    this.userSubject.next(null);
  }

  public get CurrentUser(): any {
    return this.userSubject.value;
  }

}
