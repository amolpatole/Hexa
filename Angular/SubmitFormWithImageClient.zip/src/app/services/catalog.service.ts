import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CatalogItem } from '../models/catalog-item';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CatalogService {

  //readonly API_BASE_URL: string = "http://localhost:58348/api/Catalog";
  readonly API_BASE_URL: string = "https://amol-catalogapi.azurewebsites.net/api/Catalog";

  constructor(private httpClient: HttpClient) {
    
  }

  addProduct(formData: FormData): Observable<CatalogItem> {
    return this.httpClient.post<CatalogItem>(`${this.API_BASE_URL}/product`, formData);
  }

  getProducts():Observable<CatalogItem[]>{
    return this.httpClient.get<CatalogItem[]>(this.API_BASE_URL);

  }
}
