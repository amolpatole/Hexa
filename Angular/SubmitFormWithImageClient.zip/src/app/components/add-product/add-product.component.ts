import { Component, OnInit } from '@angular/core';
import { CatalogItem } from 'src/app/models/catalog-item';
import { CatalogService } from 'src/app/services/catalog.service';
import { Router } from '@angular/router';

@Component({
  selector: 'add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  product: CatalogItem;

  constructor(private catalogSVC : CatalogService, private router: Router) {
    this.product = {
      name: "",
      price: 0,
      quantity: 0,
      reorderLevel: 0,
      manufacturingDate: undefined
    };
  }

  ngOnInit() {
  }

  save(form, image) {
    if (form.valid) {
      let formData: FormData = new FormData();
      formData.append("name", this.product.name);
      formData.append("price", this.product.price.toString());
      formData.append("quantity", this.product.quantity.toString());
      formData.append("manufacturingDate", this.product.manufacturingDate.toString());
      formData.append("reorderLevel", this.product.reorderLevel.toString());
      formData.append("image", image.files[0], image.files[0].name);
      
      this.catalogSVC.addProduct(formData).subscribe(
        result=> {
          console.log(result);
          alert("Success");
          this.router.navigate(['/']);
        },
        err=>{
          console.log(err);
          alert("Failed");
        }
      );

    } else {
      alert("Invalid form data");
    }
  }

}
