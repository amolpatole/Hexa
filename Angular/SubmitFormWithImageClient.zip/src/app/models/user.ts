export interface User{
    id?: number;
    name: string;
    username: string;
    password: string;
    email: string;
    mobile: string; 
    role:string
}