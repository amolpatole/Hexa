import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserService } from '../services/user.service';

@Injectable()

export class AuthInterceptorService implements HttpInterceptor {

  constructor(private userSVC: UserService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (this.userSVC.CurrentUser) {
      if (req.url.endsWith("/api/Catalog/product") && req.method == "POST") {
        req = req.clone({
          setHeaders: {
            "Accept": "application/json",
            "Authorization": `Bearer ${this.userSVC.CurrentUser.token}`
          }
        });
      } else {
        req = req.clone({
          setHeaders: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": `Bearer ${this.userSVC.CurrentUser.token}`
          }
        });
      }
    }
    return next.handle(req);
  }

}
