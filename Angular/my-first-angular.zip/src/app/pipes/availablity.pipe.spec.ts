import { AvailablityPipe } from './availablity.pipe';

describe('AvailablityPipe', () => {
  it('create an instance', () => {
    const pipe = new AvailablityPipe();
    expect(pipe).toBeTruthy();
  });
});
