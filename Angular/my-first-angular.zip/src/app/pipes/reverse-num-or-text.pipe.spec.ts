import { ReverseNumOrTextPipe } from './reverse-num-or-text.pipe';

describe('ReverseNumOrTextPipe', () => {
  it('create an instance', () => {
    const pipe = new ReverseNumOrTextPipe();
    expect(pipe).toBeTruthy();
  });
});
