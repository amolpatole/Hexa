import { from } from 'rxjs';

export * from './home/home.component';
export * from './about/about.component';
export * from './detail/detail.component'
export * from './add-product/add-product.component'
export * from './register/register.component';
export * from './login/login.component';
export * from './not-found/not-found.component'